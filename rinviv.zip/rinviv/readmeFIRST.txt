Thougn not required, this looks best if you have a Windows 11 system reskinned using Windhawk, DWMBlurGlass, and Open Shell


Follow the settings in the SetupInstructionsImages folder

Import the theme to Vivaldi

Right click the toolbar and select "Customize Toolbar"

Remove the show panel and space buttons from the toolbar

Grab the tabs arrow and place it to the left of the forward and back buttons

Grab the reload icon and shift it to the right of the address bar

Remove all icons to the left of the newly placed reload button

Place the home icon under "address bar" to the right of the reload button


EMAIL LINK TO THIS PAGE BUTTON

Go into settings and quick commands. Scroll down to command chain and click +

Name your chain "email a link to this page"

In command 1, select copy page address

In Command 2, select Open Link In New Tab

In Command Parameter, paste mailto:?body=%0A%0A

Place this button to the right of your home button

Go into icons under theme settings and add the Mail icon from the ExtraImages folder to Email a Link to this Page

This button will copy the page link into your clipboard and open your email app for you to paste.


PRINT THIS PAGE BUTTON

Follow the first 2 steps for the first custom button but name your chain "Print Current Page

Set command 1 to Print

Place this button to the right of your Email link to this page button

Go into icons under theme settings and add the Print icon from the ExtraImages folder to Email a Link to this Page

This will print your current page


Place the downloads button to the right of your Print This Page button


PASSWORD MANAGER BUTTON

Follow the first 2 steps for the first custom button but name your chain "View and manage your saved passwords"

Set command 1 to Open Link In New Tab

Paste this into command parameter: vivaldi:password-manager/settings

Place this button to the right of your Email link to this page button

Go into icons under theme settings and add the password manager icon from the ExtraImages folder to the View and Manage Your Saved Passwords button
This will print your current page


HELP BUTTON

Follow the first 2 steps for the first custom button but name your chain "Help"

Set command 1 to Open Link In New Tab

Paste this into command parameter: Vivaldi Help

Place this button to the right of your Passwords button

Go into icons under theme settings and add the help icon from the ExtraImages folder to the View and Manage Your Saved Passwords button
This will print your current page


Place the extensions button next to the help button


If for some reason the icons included in the theme by default didnt appear, use the EmergencyImages and import them

Right click bookmarks in your bookmark bar and rename it to favorites

OPTIONAL

Rename Vivaldi shortcut to Internet Explorer or RinViv and change the icon to the included IE or RinViv icons

Download the Youtube Redux extension for classic Youtube
